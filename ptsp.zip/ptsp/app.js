const express = require('express');
const app = express();
const path = require('path');
const expressLayout = require('express-ejs-layouts');
const { Pool } = require('pg');
const pgFormat = require('pg-format');
const pool = new Pool({
    user: 'admin_kuburin',
    password: '123',
    host: 'localhost',
    database: 'db_kuburin'
});


app.use(express.json()); // use JSON format
app.use(express.urlencoded({extended: false})); // use express urlencode

// Set up view engine, layout and layout path
app.set(path.join(__dirname, '/views'));
app.set('view engine', 'ejs');
app.use(expressLayout);

// Set up path for bootstrap and asset
app.use('/jquery', express.static(__dirname + '/node_modules/jquery/dist/jquery.js'));
// app.use('/popper', express.static(__dirname + '/node_modules/popper.js/dist/popper.js'));
app.use('/popper', express.static(__dirname + '/node_modules/popper.js/dist/umd/popper.js'));
app.use('/bootstrap', express.static(__dirname + '/node_modules/bootstrap/dist'));

// Models
pool.query('SELECT * FROM coba()', (error, result) => {
    if(error) throw error;
    console.log(result.rows[0]);
});

const getDataDaftar = () => new Promise((resolve, reject) => {
    var sqlGetDaftar = 'SELECT * FROM ptsp_data_daftar()';
    pool.query(sqlGetDaftar, (error, result) => {
        if(error) throw error;
        resolve(result.rows);
    })
});

const getDataPerpanjang = () => new Promise((resolve, reject) => {
    var sqlGetPerpanjang = `SELECT * FROM ptsp_get_perpanjang()`;
    pool.query(sqlGetPerpanjang, (error, result) => {
        if(error) throw error;
        resolve(result.rows);
    })
})

const sendStatus = (kdDaftar, stat) => new Promise((resolve, reject) => {
    var sqlSendStat = `SELECT * FROM ptsp_send_daftar('${kdDaftar}', ${stat})`;
    pool.query(sqlSendStat, (error, result) => {
        if(error) throw error;
        resolve(result.rows[0]);
    })
});

const sendPerpanjang = (kdPerpanjang) => new Promise((resolve, reject) => {
    var sqlPerpanjang = `SELECT * FROM ptsp_send_perpanjang('${kdPerpanjang}')`;
    pool.query(sqlPerpanjang,(error, result) => {
        if(error) throw error;
        resolve(result.rows[0]);
    })
})

const addNotification = (kdNotif, textNotif, kdDaftar, kdPerpanjang) => new Promise((resolve, reject) => {
    getDaftar = kdDaftar != null ? kdDaftar : 'null';
    getPerpanjang = kdPerpanjang != null ? kdPerpanjang : 'null';
    var sqlAddNotif = `SELECT * FROM insert_notifikasi('${kdNotif}', '${textNotif}', '${getDaftar}', '${getPerpanjang}', null, null)`;
    pool.query(sqlAddNotif, (error, result) => {
        if(error) throw error;
        resolve(result.rows[0]);
    })
})


app.get('/', (req, res) => {
    Promise.all([
        getDataDaftar(),
        getDataPerpanjang()
    ])
    .then(data => {
        res.render('index', {
            layout:'layouts/main.ejs',
            dataDaftar: data[0],
            dataPerpanjang: data[1]
        })
    })
    .catch(error => console.error(error));
})

// app.get('/daftar/:kdDaftar/:stat', (req, res) => {
//     console.log(req.params.kdDaftar, req.params.stat);
    // sendStatus(req.params.kdDaftar, req.params.stat)
    // .then(data => { 
    //     if(data.ptsp_send_daftar == true) {
    //         addNotification()
    //     }
    //     res.send(data);
        
    // })
    // .catch(error => console.error(error));
// })
app.post('/daftar/send-daftar', (req, res) => {
    console.table(req.body);
    sendStatus(req.body.kdDaftar, req.body.stat)
    .then(data => { 
        if(data.ptsp_send_daftar == true) {
            addNotification(req.body.kdNotif, req.body.konten, req.body.kdDaftar)
            .then(data => {
                hasil = data.inserted == true ? 200 : 500;
                // res.sendStatus(hasil);
                res.send(JSON.stringify(data.date_inserted));
            })
            .catch(error => console.error(error));
        } else {
            res.sendStatus(500);
        }
    })
    .catch(error => console.error(error));
})

app.post('/perpanjang/send-perpanjang', (req, res) => {
    console.table(req.body);
    sendPerpanjang(req.body.kdPerpanjang)
    .then(data => { 
        if(data.ptsp_send_perpanjang == true) {
            addNotification(req.body.kdNotif, req.body.konten, null, req.body.kdPerpanjang)
            .then(data => {
                hasil = data.inserted == true ? 200 : 500;
                // res.sendStatus(hasil);
                res.send(JSON.stringify(data.date_inserted));
            })
            .catch(error => console.error(error));
        } else {
            res.sendStatus(500);
        }
    })
    .catch(error => console.error(error));
})
// app.get('/perpanjang/:kdPerpanjang', (req, res) => {
//     console.log(req.params.kdPerpanjang);
    // sendPerpanjang(req.params.kdPerpanjang)
    // .then(data => { res.send(data) })
    // .catch(error => console.error(error));
// })

PORT = 4001;
app.listen(PORT, () => console.log(`PTSP runnning on port ${PORT} `));
module.exports = app;