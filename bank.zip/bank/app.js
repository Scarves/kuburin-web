const express = require('express');
const app = express();
const path = require('path');
const expressLayout = require('express-ejs-layouts');
const { Pool } = require('pg');
const pgFormat = require('pg-format');
const pool = new Pool({
    user: 'admin_kuburin',
    password: '123',
    host: 'localhost',
    database: 'db_kuburin'
});


app.use(express.json()); // use JSON format
app.use(express.urlencoded({extended: false})); // use express urlencode

// Set up view engine, layout and layout path
app.set(path.join(__dirname, '/views'));
app.set('view engine', 'ejs');
app.use(expressLayout);

// Set up path for bootstrap and asset
app.use('/jquery', express.static(__dirname + '/node_modules/jquery/dist/jquery.js'));
// app.use('/popper', express.static(__dirname + '/node_modules/popper.js/dist/popper.js'));
app.use('/popper', express.static(__dirname + '/node_modules/popper.js/dist/umd/popper.js'));
app.use('/bootstrap', express.static(__dirname + '/node_modules/bootstrap/dist'));

// Models
pool.query('SELECT * FROM coba()', (error, result) => {
    if(error) throw error;
    console.log(result.rows[0]);
});

const getDataPembayaran = () => new Promise((resolve, reject) => {
    var sqlGetDaftar = 'SELECT * FROM bank_data_pembayaran()';
    pool.query(sqlGetDaftar, (error, result) => {
        if(error) throw error;
        resolve(result.rows);
    })
});

const sendStatus = (kdPembayaran) => new Promise((resolve, reject) => {
    var sqlSendStat = `SELECT * FROM bank_send_pembayaran('${kdPembayaran}')`;
    pool.query(sqlSendStat, (error, result) => {
        if(error) throw error;
        resolve(result.rows[0]);
    })
});

const addNotification = (kdNotif, textNotif, kdPembayaran) => new Promise((resolve, reject) => {
    var sqlAddNotif = `SELECT * FROM insert_notifikasi('${kdNotif}', '${textNotif}', null, null, '${kdPembayaran}', null)`;
    pool.query(sqlAddNotif, (error, result) => {
        if(error) throw error;
        resolve(result.rows[0]);
    })
})


app.get('/', (req, res) => {
    getDataPembayaran()
    .then(data => {
        res.render('index', {
            layout:'layouts/main.ejs',
            dataPembayaran: data
        })
    })
    .catch(error => console.error(error));
})

app.post('/transaksi', (req, res) => {
    sendStatus(req.body.kdPembayaran)
    .then(data => { 
        if(data.bank_send_pembayaran == true) {
            addNotification('BYR', req.body.content, req.body.kdPembayaran)
            .then(result => {
                res.send(JSON.stringify(result.date_inserted));
            })
        } else {
            res.sendStatus(500);
        }
    })
    .catch(error => console.error(error));
})

PORT = 5001;
app.listen(PORT, () => console.log(`BANK runnning on port ${PORT} `));
module.exports = app;